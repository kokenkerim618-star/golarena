// GolArena front-end demo only. No real accounts, server storage, or money movement.
const $ = (id) => document.getElementById(id);
const paymentRequests = [];
const supportMessages = [];
let demoBalance = 1250;
let authMode = 'register';

function formatTRY(value) {
  return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(value);
}
function refreshBalance() { $('balance').textContent = formatTRY(demoBalance); }
function showAuth(mode) {
  authMode = mode;
  $('authTitle').textContent = mode === 'register' ? 'Üye ol' : 'Giriş yap';
  $('authSubmit').textContent = mode === 'register' ? 'Demo hesabı oluştur' : 'Demo giriş';
  $('authResult').textContent = '';
  $('authModal').hidden = false;
}
document.querySelectorAll('[data-auth]').forEach(btn => btn.addEventListener('click', () => showAuth(btn.dataset.auth)));
$('closeAuth').addEventListener('click', () => $('authModal').hidden = true);
$('authModal').addEventListener('click', e => { if (e.target === $('authModal')) $('authModal').hidden = true; });
document.addEventListener('keydown', e => { if (e.key === 'Escape') { $('authModal').hidden = true; $('historyModal').hidden = true; } });
$('authForm').addEventListener('submit', e => {
  e.preventDefault();
  const email = $('authEmail').value.trim();
  $('authResult').textContent = `${authMode === 'register' ? 'Kayıt' : 'Giriş'} demosu tamamlandı (${email}). Gerçek hesap oluşturulmadı ve parola saklanmadı.`;
  $('authInlineResult').textContent = 'Bu yalnızca demo formudur; gerçek oturum açılmadı.';
});

function renderPaymentHistory() {
  const targets = [$('paymentHistory'), $('modalHistory'), $('adminPayments')];
  targets.forEach(target => {
    target.replaceChildren();
    if (!paymentRequests.length) {
      const p = document.createElement('p');
      p.className = 'muted'; p.textContent = 'Henüz demo talebi oluşturulmadı.';
      target.appendChild(p); return;
    }
    paymentRequests.slice().reverse().forEach(req => {
      const item = document.createElement('div');
      item.className = 'history-item';
      const info = document.createElement('div');
      const strong = document.createElement('strong');
      strong.textContent = `${formatTRY(req.amount)} · ${req.id}`;
      const small = document.createElement('small');
      small.textContent = `${req.sender || 'Örnek kullanıcı'} · ${req.time}`;
      info.append(strong, small);
      const state = document.createElement('span');
      state.className = 'state'; state.textContent = 'DEMO / BEKLEMEDE';
      item.append(info, state); target.appendChild(item);
    });
  });
  $('paymentCount').textContent = paymentRequests.length;
}
$('depositForm').addEventListener('submit', e => {
  e.preventDefault();
  const amount = Number($('amount').value);
  const sender = $('sender').value.trim();
  const note = $('depositNote').value.trim();
  const id = 'DEMO-' + String(paymentRequests.length + 1).padStart(4, '0');
  paymentRequests.push({ id, amount, sender, note, time: new Date().toLocaleString('tr-TR') });
  $('depositResult').textContent = `Demo talep oluşturuldu: ${id}. Durum: Beklemede. Para gönderilmedi, bakiye değişmedi ve gerçek ödeme onayı verilmedi.`;
  $('depositForm').reset();
  renderPaymentHistory();
});
$('openDeposit').addEventListener('click', () => $('depositPanel').scrollIntoView({ behavior: 'smooth' }));
$('openHistory').addEventListener('click', () => { renderPaymentHistory(); $('historyModal').hidden = false; });
$('closeHistory').addEventListener('click', () => $('historyModal').hidden = true);
$('historyModal').addEventListener('click', e => { if (e.target === $('historyModal')) $('historyModal').hidden = true; });
$('clearHistory').addEventListener('click', () => {
  paymentRequests.length = 0; $('depositResult').textContent = ''; renderPaymentHistory();
});

function renderSupport() {
  const root = $('adminMessages'); root.replaceChildren();
  $('messageCount').textContent = supportMessages.length;
  if (!supportMessages.length) {
    const p = document.createElement('p'); p.className = 'muted'; p.textContent = 'Henüz destek mesajı yok.'; root.appendChild(p); return;
  }
  supportMessages.slice().reverse().forEach(msg => {
    const item = document.createElement('article'); item.className = 'admin-item';
    const title = document.createElement('strong'); title.textContent = 'Yeni destek mesajı';
    const p = document.createElement('p'); p.textContent = msg.text;
    const small = document.createElement('small'); small.textContent = msg.time;
    item.append(title, p, small); root.appendChild(item);
  });
}
$('supportForm').addEventListener('submit', e => {
  e.preventDefault();
  const input = $('supportMessage'); const message = input.value.trim(); if (!message) return;
  supportMessages.push({ text: message, time: new Date().toLocaleString('tr-TR') });
  input.value = '';
  $('supportStatus').textContent = 'Mesaj demo yönetim panelinde gösteriliyor. Sunucuya gönderilmedi.';
  renderSupport();
});
$('clearSupport').addEventListener('click', () => { supportMessages.length = 0; $('supportStatus').textContent = ''; renderSupport(); });
$('clearAll').addEventListener('click', () => {
  paymentRequests.length = 0; supportMessages.length = 0; $('depositResult').textContent = ''; $('supportStatus').textContent = '';
  renderPaymentHistory(); renderSupport();
});
document.querySelectorAll('[data-tab]').forEach(btn => btn.addEventListener('click', () => {
  document.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('active', b === btn));
  const showPayments = btn.dataset.tab === 'payments';
  $('adminMessages').hidden = showPayments; $('adminPayments').hidden = !showPayments;
  renderPaymentHistory(); renderSupport();
}));
refreshBalance(); renderPaymentHistory(); renderSupport();
