GOLARENA V2 — SİYAH/YEŞİL SPOR PORTALI DEMOSU
=============================================

Dosyalar:
- index.html: ana sayfa, maç kartları, üyelik/giriş modalı, demo cüzdan ve ödeme talebi, canlı destek, demo yönetim paneli
- style.css: responsive siyah/yeşil tasarım
- script.js: demo etkileşimleri
- README.txt: bu rehber

ÖNEMLİ
Bu paket gerçek ödeme veya bahis sistemi değildir:
- Gerçek IBAN, banka bilgisi, kart numarası veya para transferi yoktur.
- Ödeme talepleri yalnızca örnek durum olarak gösterilir; gerçek ödeme onayı değildir.
- Bakiye örnektir, gerçek para değildir.
- Üyelik ve giriş formları kimlik doğrulamaz; parola saklanmaz.
- Canlı destek mesajları yalnızca sayfa açıkken bellekte tutulur; sunucuya kaydedilmez.
- Yönetim paneli gerçek bir güvenlik/rol sistemi içermez.
Gerçek kullanıcı verisi ve ödeme işlemleri için güvenli backend, kimlik doğrulama, erişim kontrolü,
veri koruma ve uygulanabilir lisans/mevzuat şartları gerekir.

ÜCRETSİZ YAYINLAMA
1. GitHub'da `golarena` deposunu aç.
2. Bu klasördeki dört dosyayı deponun ana dizinine yükle (ZIP'i değil, çıkartılmış dosyaları).
3. Cloudflare hesabında Workers & Pages > Create application > Pages > Import an existing Git repository seç.
4. GitHub deposunu bağla.
5. Düz statik site için build command `exit 0`, output directory `.` veya arayüzün kabul ettiği kök dizin olsun.
6. Deploy et. Platform bir `pages.dev` adresi üretir.
Kılavuz: https://developers.cloudflare.com/pages/get-started/git-integration/

Bu dosyalar demo ve spor portalı arayüzü amacıyla hazırlanmıştır.
